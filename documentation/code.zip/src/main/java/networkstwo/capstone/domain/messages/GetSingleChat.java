package networkstwo.capstone.domain.messages;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.UUID;

public record GetSingleChat(
        @JsonProperty("token") String token,
        @JsonProperty("operation") String operation,
        @JsonProperty("chatId") UUID chatId
) {
}
